insert into accounts(accountid,name,type) values(1,'kumar','savings');
insert into accounts(accountid,name,type) values(2,'john','current');